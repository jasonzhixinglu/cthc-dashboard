#%%

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import statsmodels.api as sm
from statsmodels.tsa.ar_model import AutoReg
from statsmodels.multivariate.pca import PCA
from statsmodels.tsa.statespace.mlemodel import MLEModel
from scipy.signal import periodogram
import numpy as np
from typing import Tuple, Optional, Dict, Any, List 

def construct_kalman_matrices(n_i, d, sigma_u, sigma_omega, sigma_psi, sigma_tau, sigma_eps_star, rho_c, lambda_c, lambda_i):
    """
    Construct the Kalman filter system matrices for:
    - Trend: μₜ + gₜ
    - Harvey cycle: cₜ, c*_ₜ
    - Sectoral weights: θᵢₜ
    """
    k_states = 4 + n_i       # μ_t, g_t, c_t, c*_t, θ₁ₜ,...,θₙₜ
    k_posdef = 3 + n_i       # uₜ, ωₜ, ω*ₜ, ψ₁ₜ,...,ψₙₜ
    k_endog = 1 + n_i        # y*_t, y_{1t}, ..., y_{nt}

    # === Design matrix Z ===
    Z = np.zeros((k_endog, k_states))
    Z[0, 0] = 1  # y*_t = μ_t + ε*_t
    for i in range(n_i):
        Z[i+1, 0] = 1                   # μ_t
        Z[i+1, 2] = lambda_i[i]         # λᵢ × cₜ
        Z[i+1, 4+i] = 1                 # θᵢₜ

    # === Observation covariance matrix H ===
    H = np.diag([sigma_eps_star**2] + [sigma_tau**2] * n_i)

    # === Transition matrix T ===
    T = np.eye(k_states)
    T[0, 1] = 1  # μ_{t+1} = μ_t + g_t
    T[2:4, 2:4] = rho_c * np.array([
        [np.cos(lambda_c), np.sin(lambda_c)],
        [-np.sin(lambda_c), np.cos(lambda_c)]
    ])  # Harvey cycle

    # === State intercept vector c ===
    c = np.zeros(k_states)
    c[1] = d

    # === Selection matrix R ===
    R = np.zeros((k_states, k_posdef))
    R[1, 0] = 1   # uₜ
    R[2, 1] = 1   # ωₜ
    R[3, 2] = 1   # ω*ₜ
    for i in range(n_i):
        R[4+i, 3+i] = 1  # ψᵢₜ

    # === State covariance matrix Q ===
    Q = np.diag([sigma_u**2, sigma_omega**2, sigma_omega**2] + [sigma_psi**2]*n_i)

    return {
        'design': Z,
        'obs_cov': H,
        'transition': T,
        'state_intercept': c,
        'selection': R,
        'state_cov': Q
    }

def est_initial_conditions(data, g_0, rho_c, sigma_omega):
    # setup initial conditions
    data_hp_cycle = np.zeros_like(data)
    data_hp_trend = np.zeros_like(data)
    for i in range(data.shape[0]):
        data_hp_cycle[i, :], data_hp_trend[i, :] = sm.tsa.filters.hpfilter(data[i, :], lamb=1600)

    # estimate of initial states
    state_init = np.zeros(data.shape[0] + 3)
    state_init[0] = data_hp_trend[0, 0]
    state_init[1] = g_0
    for i in range(data.shape[0]-1):
        state_init[4+i] = data_hp_trend[1+i, 0] - data_hp_trend[0, 0]

    # estimate of initial prediction standard deviations
    pred_std_init = np.zeros(data.shape[0] + 3)
    pred_std_init[0] = np.std(data_hp_cycle[0, :]) * 2
    pred_std_init[1] = 1.0 # pre-specified
    pred_std_init[2] = np.sqrt(1/(1 - rho_c**2)) * sigma_omega
    pred_std_init[3] = np.sqrt(1/(1 - rho_c**2)) * sigma_omega
    pred_std_init[4:] = np.std(data_hp_cycle[1:, :]) + np.std(data_hp_cycle[0, :])

    # get initial conditions
    x0 = state_init
    P0 = np.diag(pred_std_init**2)

    return x0, P0

def apply_kalman_filter(data, all_params):
    # unpack parameters
    n_i, g_0, d, sigma_u, sigma_omega, sigma_psi, sigma_tau, sigma_eps_star, rho_c, lambda_c, lambda_i = all_params
    # construct Kalman filter matrices
    kf_matrices = construct_kalman_matrices(n_i, d, sigma_u, sigma_omega, sigma_psi, sigma_tau, sigma_eps_star, rho_c, lambda_c, lambda_i)
    
    # construct Kalman filter initial conditions
    x0, P0 = est_initial_conditions(
        data=data,
        g_0=g_0,
        rho_c=rho_c,
        sigma_omega=sigma_omega
    )
    
    # instantiate a statespace model with Kalman filter matrices
    kf = MLEModel(pd.DataFrame(data.T), k_states=n_i+4, k_posdef=n_i+3)
    kf['design'] = kf_matrices['design']
    kf['obs_cov'] = kf_matrices['obs_cov']
    kf['transition'] = kf_matrices['transition']
    kf['state_intercept'] = kf_matrices['state_intercept']
    kf['selection'] = kf_matrices['selection']
    kf['state_cov'] = kf_matrices['state_cov']
    
    # fill in initial conditions
    kf.initialize_known(x0, P0)
    
    return kf.smooth([])

#%% 

np.random.seed(42)  # For reproducibility

# === Parameters ===
T = 100                      # Number of time steps
n_i = 6                      # Number of sectoral indicators
n_states = 4 + n_i           # Number of states (μₜ, gₜ, cₜ, c*ₜ, θ₁ₜ,...,θₙₜ)
d = -0.03                    # Constant drift in trend growth
lambda_i_mean = 3.0          # Mean cycle loading
lambda_i_std = 1.0           # Std dev of cycle loading
sigma_u = 0.1                # Std dev of innovation in g_t
sigma_psi = 5.0              # Std dev of ψ_it
sigma_tau = 5.0              # Std dev of τ_it
sigma_eps_star = 5.0         # Std dev of ε*_t (smoothed GDP noise)
g_0 = 6.0                    # Initial growth rate

# === Harvey cycle parameters ===
rho_c = 0.95
lambda_c = 2 * np.pi / 20
sigma_omega = 0.5
sigma_c = sigma_omega / np.sqrt(1 - rho_c**2)

# === Initialize latent state variables ===
mu_t = np.zeros(T)
g_t = np.zeros(T)
g_t[0] = g_0
eps_t = np.zeros(T)
y_true = np.zeros(T)
y_obs_t = np.zeros(T)

# === Sectoral components ===
mu_it = np.zeros((n_i, T))
theta_it = np.zeros((n_i, T))
theta_it[:, 0] = np.random.normal(0, sigma_psi, n_i)
eps_it = np.zeros((n_i, T))
tau_it = np.zeros((n_i, T))
y_it = np.zeros((n_i, T))
lambda_i = np.random.normal(lambda_i_mean, lambda_i_std, n_i)

# === Harvey cycle components ===
c_t = np.zeros(T)
c_star_t = np.zeros(T)
omega_t = np.random.normal(0, sigma_omega, T)
omega_star_t = np.random.normal(0, sigma_omega, T)

# Simulate bivariate Harvey cycle
for t in range(1, T):
    c_t[t] = rho_c * (np.cos(lambda_c) * c_t[t-1] + np.sin(lambda_c) * c_star_t[t-1]) + omega_t[t]
    c_star_t[t] = rho_c * (-np.sin(lambda_c) * c_t[t-1] + np.cos(lambda_c) * c_star_t[t-1]) + omega_star_t[t]
eps_t = c_t  # GDP cycle ε_t = c_t

# === Simulate shocks ===
u_t = np.random.normal(0, sigma_u, T)
eta_t = np.zeros(T)  # Not used (would be for 3-layer trend)
psi_it = np.random.normal(0, sigma_psi, (n_i, T))
eps_star_t = np.random.normal(0, sigma_eps_star, T)

# === Simulate trend ===
for t in range(1, T):
    g_t[t] = g_t[t-1] + d + u_t[t]
    mu_t[t] = mu_t[t-1] + g_t[t-1]

# === Generate GDP series ===
y_true = mu_t + eps_t
y_obs_t = mu_t + eps_star_t

# === Simulate sectoral indicators ===
for i in range(n_i):
    for t in range(T):
        theta_it[i, t] = theta_it[i, t-1] + psi_it[i, t]
        mu_it[i, t] = mu_t[t] + theta_it[i, t]
        tau_it[i, t] = np.random.normal(0, sigma_tau)
        eps_it[i, t] = lambda_i[i] * eps_t[t] + tau_it[i, t]
        y_it[i, t] = mu_it[i, t] + eps_it[i, t]

data = np.vstack([y_obs_t, y_it])
true_states = np.vstack([mu_t, g_t, c_t, c_star_t, theta_it])
sector_names = np.arange(1, n_i+1)
n_sectors = data.shape[0] - 1
n_states = n_sectors + 4
T = data.shape[1]


#%%

# specify HP filter lambda
lamb_hp = 1600

# specify output gap standard deviation
sigma_c_exog = 2.0

# estimate sig_eps_star and d
g_star = np.diff(y_obs_t)
sigma_eps_star_hat = np.sqrt(np.var(np.diff(g_star)) / 6)
g_0_hat, d_hat = sm.OLS(g_star, sm.add_constant(np.arange(len(g_star)))).fit().params

# estimate sig_u
uc_mod = sm.tsa.UnobservedComponents(y_obs_t, level='strend')
uc_res = uc_mod.fit(method='powell', disp=False)
sigma_u_hat = np.sqrt(uc_res.params[1])

# estimate sigma_psi
sector_i_cycle = np.zeros_like(y_it)
sector_i_trend = np.zeros_like(y_it)
psi_i_std = np.zeros(n_i)
for i in range(n_i):
    sector_i_cycle[i, :], sector_i_trend[i, :] = sm.tsa.filters.hpfilter(y_it[i, :], lamb=lamb_hp)
    output_mod = sm.tsa.UnobservedComponents(sector_i_trend[i, :], level='llevel')
    output_res = output_mod.fit(method='powell', disp=False)
    psi_i_std[i] = np.sqrt(output_res.params[1])
sigma_psi_hat = np.mean(psi_i_std)

# estimate lambda_i
pca_model = PCA(sector_i_cycle.T, ncomp=1, standardize=False, demean=False)
lambda_i_hat = pca_model.loadings[:, 0]
lambda_i_hat = lambda_i_hat * lambda_i_mean / np.mean(lambda_i_hat)

# estimate sigma_tau
sigma_tau_hat = np.sqrt(np.var(sector_i_cycle) - np.var(pca_model.projection.T))

# specify first-pass Harvey cycle parameters
lambda_c_hat = 0
rho_c_hat = 0.95
sigma_omega_hat = 1.0

# first-pass Kalman filter
all_params_hat = n_i, g_0_hat, d_hat, sigma_u_hat, sigma_omega_hat, sigma_psi_hat, sigma_tau_hat, sigma_eps_star_hat, rho_c_hat, lambda_c_hat, lambda_i_hat
res_hat = apply_kalman_filter(data, all_params_hat)

# estimate second-stage Harvey cycle parameters
c_t_hat = res_hat.states.smoothed.values[:, 2]

# estimate Harvey cycle lambda_c
f, Pxx = periodogram(pca_model.factors[:, 0], fs=1, scaling='spectrum')
idx_peak = np.argmax(Pxx[1:]) + 1  # ignore zero frequency
lambda_c_hat = 2 * np.pi * f[idx_peak]

# estimate Harvey cycle rho_c and sigma_omega
uc_mod = sm.tsa.UnobservedComponents(
    endog=c_t_hat,
    trend=False,
    cycle=True,
    stochastic_cycle=True,
    damped_cycle=True,
    irregular=False
)
uc_res = uc_mod.fit(disp=False)
rho_c_hat = uc_res.params[2]
sigma_omega_hat = sigma_c_exog * np.sqrt(1 - rho_c_hat**2)

# second-stage Kalman filter
all_params_hat = n_i, g_0_hat, d_hat, sigma_u_hat, sigma_omega_hat, sigma_psi_hat, sigma_tau_hat, sigma_eps_star_hat, rho_c_hat, lambda_c_hat, lambda_i_hat
res_hat = apply_kalman_filter(data, all_params_hat)

# display second-stage parameters
initial_params = all_params_hat
initial_x0, initial_P0 = est_initial_conditions(data, g_0_hat, rho_c_hat, sigma_omega_hat)

#%%

# # first-stage estimation

# # read data
# n_i = data.shape[0] - 1
# T = data.shape[1]
# y_obs_t = data[0, :]
# y_it = data[1:, :]

# # specify HP filter lambda
# lamb_hp = 1600

# # specify output gap standard deviation
# sigma_c_exog = 2.0

# # estimate sig_eps_star and d
# g_star = np.diff(y_obs_t)
# sigma_eps_star_hat = np.sqrt(np.var(np.diff(g_star)) / 6)
# g_0_hat, d_hat = sm.OLS(g_star, sm.add_constant(np.arange(len(g_star)))).fit().params

# # estimate sig_u
# uc_mod = sm.tsa.UnobservedComponents(y_obs_t, level='strend')
# uc_res = uc_mod.fit(method='powell', disp=False)
# sigma_u_hat = np.sqrt(uc_res.params[1])

# # estimate sigma_psi
# sector_i_cycle = np.zeros_like(y_it)
# sector_i_trend = np.zeros_like(y_it)
# psi_i_std = np.zeros(n_i)
# for i in range(n_i):
#     sector_i_cycle[i, :], sector_i_trend[i, :] = sm.tsa.filters.hpfilter(y_it[i, :], lamb=lamb_hp)
#     output_mod = sm.tsa.UnobservedComponents(sector_i_trend[i, :], level='llevel')
#     output_res = output_mod.fit(method='powell', disp=False)
#     psi_i_std[i] = np.sqrt(output_res.params[1])
# sigma_psi_hat = np.mean(psi_i_std)

# # estimate lambda_i
# pca_model = PCA(sector_i_cycle.T, ncomp=1, standardize=False, demean=False)
# lambda_i_hat = pca_model.loadings[:, 0]
# lambda_i_hat = lambda_i_hat * lambda_i_mean / np.mean(lambda_i_hat)

# # estimate sigma_tau
# sigma_tau_hat = np.sqrt(np.var(sector_i_cycle) - np.var(pca_model.projection.T))

# # specify first-pass Harvey cycle parameters
# lambda_c_hat = 0
# rho_c_hat = 0.95
# sigma_omega_hat = 1.0

# # first-pass Kalman filter
# all_params_hat = n_i, g_0_hat, d_hat, sigma_u_hat, sigma_omega_hat, sigma_psi_hat, sigma_tau_hat, sigma_eps_star_hat, rho_c_hat, lambda_c_hat, lambda_i_hat
# res_hat = apply_kalman_filter(data, all_params_hat)

# # estimate second-stage Harvey cycle parameters
# c_t_hat = res_hat.states.smoothed.values[:, 2]

# # estimate Harvey cycle lambda_c
# f, Pxx = periodogram(c_t_hat, fs=1, scaling='spectrum')
# idx_peak = np.argmax(Pxx[1:]) + 1  # ignore zero frequency
# lambda_c_hat = 2 * np.pi * f[idx_peak]

# # estimate Harvey cycle rho_c and sigma_omega
# uc_mod = sm.tsa.UnobservedComponents(
#     endog=c_t_hat,
#     trend=False,
#     cycle=True,
#     stochastic_cycle=True,
#     damped_cycle=True,
#     irregular=False
# )
# uc_res = uc_mod.fit(disp=False)
# rho_c_hat = uc_res.params[2]
# sigma_omega_hat = sigma_c_exog * np.sqrt(1 - rho_c_hat**2)
# lambda_c_hat, rho_c_hat, sigma_omega_hat

# # second-stage Kalman filter
# all_params_hat = n_i, g_0_hat, d_hat, sigma_u_hat, sigma_omega_hat, sigma_psi_hat, sigma_tau_hat, sigma_eps_star_hat, rho_c_hat, lambda_c_hat, lambda_i_hat
# res_hat = apply_kalman_filter(data, all_params_hat)

# # display second-stage parameters
# initial_params = all_params_hat
# initial_x0, initial_P0 = est_initial_conditions(data, g_0_hat, rho_c_hat, sigma_omega_hat)


#%%

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import statsmodels.api as sm
from statsmodels.tsa.ar_model import AutoReg
from statsmodels.multivariate.pca import PCA
from pymc_extras.statespace.core import PyMCStateSpace
from pymc_extras.statespace.utils.constants import (ALL_STATE_DIM,ALL_STATE_AUX_DIM,OBS_STATE_DIM,SHOCK_DIM,)
from pymc_extras.statespace.models.utilities import make_default_coords
import numpy as np
import pytensor.tensor as pt
import pymc as pm
from typing import Tuple, Optional, Dict, Any, List 
import arviz as az
import simdkalman
from pytensor.printing import Print
# from pykalman import KalmanFilter


# # # # Configure JAX to use GPU
import jax
jax.config.update('jax_platform_name', 'cpu')
jax.config.update('jax_enable_x64', True)  # Enable double precision

# # Configure PyTensor early with appropriate settings
import pytensor
import os

class CointegratedTrendHarveyCycle(PyMCStateSpace):
    def __init__(self, n_i):
        self.n_i = n_i
        self.k_states = 4 + self.n_i
        self.k_endog = 1 + self.n_i
        self.k_posdef = 3 + self.n_i
        super().__init__(k_endog=self.k_endog, k_states=self.k_states, k_posdef=self.k_posdef)
 
    @property
    def coords(self):
        return make_default_coords(self)

    @property
    def shock_names(self):
        return ['u', 'omega', 'omega_star'] + [f'psi_{i+1}' for i in range(self.n_i)]

    @property
    def param_names(self):
        return [
            'x0', 'P0', 
            'd', 'sigma_u', 'sigma_omega', 'sigma_psi', 'sigma_tau', 
            'sigma_eps_star', 'rho_c', 'lambda_c', 'lambda_i'
            ]
    
    @property
    def observed_states(self):
        return ['y_obs'] + [f'y_{i+1}' for i in range(self.n_i)]
    
    @property
    def state_names(self):
        return ['mu', 'g', 'c', 'c_star'] + [f'theta_{i+1}' for i in range(self.n_i)]
    
    @property
    def param_dims(self):
        return {
            "x0": (ALL_STATE_DIM,),
            "P0": (ALL_STATE_DIM, ALL_STATE_DIM),
            "d": (),
            "sigma_u": (),
            "sigma_omega": (),
            "sigma_psi": (),
            "sigma_tau": (),
            "sigma_eps_star": (),
            "rho_c": (),
            "lambda_c": (),
            "lambda_i": (self.n_i,)
         }
    
    @property
    def param_info(self):
        info = {
            "x0": {
                "shape": (self.k_states,),
                "constraints": "None",
            },
            "P0": {
                "shape": (self.k_states, self.k_states),
                "constraints": "Positive Semi-definite",
            },
            "d": {
                "shape": (),
                "constraints": "Negative",
            },
            "sigma_u": {
                "shape": (),
                "constraints": "Positive",
            },
            "sigma_omega": {
                "shape": (),
                "constraints": "Positive",
            },
            "sigma_psi": {
                "shape": (),
                "constraints": "Positive",
            },
            "sigma_tau": {
                "shape": (),
                "constraints": "Positive",
            },
            "sigma_eps_star": {
                "shape": (),
                "constraints": "Positive",
            },
            "rho_c": {
                "shape": (),
                "constraints": "0 < rho_c < 1",
            },
            "lambda_c": {
                "shape": (),
                "constraints": "Positive",
            },
            "lambda_i": {
                "shape": (self.n_i,),
                "constraints": "None",
            },
        }
 
        # Lazy way to add the dims without making any typos
        for name in self.param_names:
            info[name]["dims"] = self.param_dims[name]
 
        return info

    def make_symbolic_graph(self):

        k = self.k_states

        # Register all model parameters
        x0_var = self.make_and_register_variable('x0', shape=(k,)) # Renamed to avoid clash
        P0_matrix = self.make_and_register_variable('P0', shape=(k, k))
        d_param = self.make_and_register_variable('d', shape=())
        sigma_u_param = self.make_and_register_variable('sigma_u', shape=())
        sigma_omega_param = self.make_and_register_variable('sigma_omega', shape=())
        sigma_psi_param = self.make_and_register_variable('sigma_psi', shape=())
        sigma_tau_param = self.make_and_register_variable('sigma_tau', shape=())
        sigma_eps_star_param = self.make_and_register_variable('sigma_eps_star', shape=())
        rho_c_param = self.make_and_register_variable('rho_c', shape=())
        lambda_c_param = self.make_and_register_variable('lambda_c', shape=())
        lambda_i_param = self.make_and_register_variable('lambda_i', shape=(self.n_i,))
        
        # Transition matrix for states
        T = np.eye(self.k_states)
        T[0, 1] = 1.0
        self.ssm['transition', :, :] = T
        self.ssm['transition', 2, 2] = rho_c_param * pm.math.cos(lambda_c_param) 
        self.ssm['transition', 2, 3] = rho_c_param * pm.math.sin(lambda_c_param) 
        self.ssm['transition', 3, 2] = - rho_c_param * pm.math.sin(lambda_c_param) 
        self.ssm['transition', 3, 3] = rho_c_param * pm.math.cos(lambda_c_param) 

        # Selection matrix (for structural shocks)
        R = np.zeros((self.k_states, self.k_posdef))
        R[1, 0] = 1.0
        R[2, 1] = 1.0
        R[3, 2] = 1.0
        for i in range(self.n_i):
            R[4 + i, 3 + i] = 1.0
        self.ssm['selection', :, :] = R

        # Design matrix (Z)
        Z_np = np.zeros((self.k_endog, self.k_states))
        Z_np[0, 0] = 1.0
        for i in range(self.n_i):
            Z_np[1 + i, 0] = 1.0
            Z_np[1 + i, 4 + i] = 1.0
        self.ssm['design', :, :] = Z_np
        
        for i in range(self.n_i):
            self.ssm['design', 1 + i, 2] = lambda_i_param[i]

        # Initial state
        self.ssm['initial_state', :] = x0_var
        self.ssm['initial_state_cov', :, :] = P0_matrix

        # Drift vector
        c = np.zeros(k)
        self.ssm['state_intercept', :] = c
        self.ssm['state_intercept', 1] = d_param

        # State innovation variances      
        diag_Q_values = pt.zeros(self.k_posdef, dtype=pytensor.config.floatX)
        diag_Q_values = pt.set_subtensor(diag_Q_values[0], sigma_u_param**2)
        diag_Q_values = pt.set_subtensor(diag_Q_values[1], sigma_omega_param**2)
        diag_Q_values = pt.set_subtensor(diag_Q_values[2], sigma_omega_param**2)
        for i in range(self.n_i):  
            shock_psi_idx = 3 + i
            diag_Q_values = pt.set_subtensor(diag_Q_values[shock_psi_idx], sigma_psi_param**2) # Variance of shock psi_{i+1}
        
        self.ssm['state_cov', :, :] = pt.diag(diag_Q_values)

        # Observation error variances
        H = np.zeros((self.k_endog, self.k_endog))
        self.ssm['obs_cov', :, :] = H
        self.ssm['obs_cov', 0, 0] = sigma_eps_star_param ** 2
        for i in range(self.n_i):
            self.ssm['obs_cov', 1 + i, 1 + i] = sigma_tau_param ** 2

    def build_model_setup_priors(self, data, initial_params, initial_x0, initial_P0):
        data = data.copy().T
        self.initial_params = initial_params
        self.initial_x0 = initial_x0
        self.initial_P0 = initial_P0

        with pm.Model(coords=self.coords) as model:

            # setup priors for x0 and specify P0 (taken as data)
            x0_mean = pm.Data("x0_mean", initial_x0)
            P0 = pm.Data("P0", initial_P0)
            x0 = pm.MvNormal('x0', mu=x0_mean, cov=P0, shape=(self.k_states,))

            # setup priors for the standard deviations
            d = pm.TruncatedNormal('d', mu=initial_params[2], sigma=np.abs(initial_params[2])/2, upper=-0.001) 
            sigma_u = pm.Exponential('sigma_u', lam = 1/initial_params[3])
            sigma_omega_hat = initial_params[4]
            # sigma_omega = pm.Exponential('sigma_omega', lam = 1/initial_params[4])
            sigma_omega = pm.Beta('sigma_omega', mu=sigma_omega_hat, sigma=sigma_omega_hat/10)
            sigma_psi = pm.Exponential('sigma_psi', lam = 1/initial_params[5])
            sigma_tau = pm.Exponential('sigma_tau', lam = 1/initial_params[6])
            sigma_eps_star = pm.Exponential('sigma_eps_star', lam = 1/initial_params[7])
            rho_hat = initial_params[8]
            rho_c = pm.Beta('rho_c', mu=rho_hat, sigma=np.sqrt(rho_hat*(1-rho_hat))/100)
            # lambda_c = pm.Exponential('lambda_c', lam = 1/initial_params[9])
            lambda_c_hat = initial_params[9]
            lambda_c = pm.Beta('lambda_c', mu=lambda_c_hat, sigma=lambda_c_hat/100)
            lambda_i = pm.MvNormal('lambda_i', mu=initial_params[10], 
                                cov=np.diag(initial_params[10]**2/400),
                                shape=(self.n_i,))
        
            self.build_statespace_graph(data=data.T, mode="JAX")
        
        return model

    def build_and_sample(self, draws, data, initial_params, initial_x0, initial_P0, **kwargs):

        # build model and setup priors
        self._pymc_model = self.build_model_setup_priors(data, initial_params, initial_x0, initial_P0)

        # sample model
        with self._pymc_model:
            trace = pm.sample(
                tune = draws, 
                draws = draws,
                cores = 1,
                nuts_sampler = "nutpie",
                nuts_sampler_kwargs = {"backend": "jax", "gradient_backend": "jax"},
                **kwargs
            )
        return trace
    
#%%

# Bayesian model estimation
n_sectors = data.shape[0] - 1
model = CointegratedTrendHarveyCycle(n_i)
trace = model.build_and_sample(draws=200, data=data.T, 
                               initial_params=initial_params, 
                               initial_x0=initial_x0,
                               initial_P0=initial_P0)

#%%

# unpack posterior parameter estimates
n_chains = len(trace.posterior.chain)
n_draws = len(trace.posterior.draw)
n_post = n_chains * n_draws

x0_post = np.float64(trace.posterior['x0']).reshape((n_chains*n_draws, n_states))
x0_post = x0_post.reshape((n_chains*n_draws, n_states))
P0_post = np.float64(trace.constant_data.P0)
d_post = np.float64(trace.posterior['d']).reshape((n_chains*n_draws))
sigma_u_post = np.float64(trace.posterior['sigma_u']).reshape((n_chains*n_draws))
sigma_omega_post = np.float64(trace.posterior['sigma_omega']).reshape((n_chains*n_draws))
sigma_psi_post = np.float64(trace.posterior['sigma_psi']).reshape((n_chains*n_draws))
sigma_tau_post = np.float64(trace.posterior['sigma_tau']).reshape((n_chains*n_draws))
sigma_eps_star_post = np.float64(trace.posterior['sigma_eps_star']).reshape((n_chains*n_draws))
rho_c_post = np.float64(trace.posterior['rho_c']).reshape((n_chains*n_draws))
lambda_c_post = np.float64(trace.posterior['lambda_c']).reshape((n_chains*n_draws))
lambda_i_post = np.float64(trace.posterior['lambda_i']).reshape((n_chains*n_draws, n_i))

# export posterior numpy arrays to npz
np.savez('simulation_posteriors.npz', 
         array1=x0_post, 
         array2=P0_post,
         array3=d_post,
         array4=sigma_u_post,
         array5=sigma_omega_post,
         array6=sigma_psi_post,
         array7=sigma_tau_post,
         array8=sigma_eps_star_post,
         array9=rho_c_post,
         array10=lambda_c_post,
         array11=lambda_i_post
)

# loading npz
loaded_data = np.load('simulation_posteriors.npz')

#%%

simulation_smoother_states = np.zeros((n_post, n_states, T))

for i in range(n_post):
    # take parameter draws
    x0_draw = x0_post[i, :]
    g_0_draw = x0_draw[1]
    P0_draw = P0_post
    d_draw = d_post[i]
    sigma_u_draw = sigma_u_post[i]
    sigma_omega_draw = sigma_omega_post[i]
    sigma_psi_draw = sigma_psi_post[i]
    sigma_tau_draw = sigma_tau_post[i]
    sigma_eps_star_draw = sigma_eps_star_post[i]
    rho_c_draw = rho_c_post[i]
    lambda_c_draw = lambda_c_post[i]
    lambda_i_draw = lambda_i_post[i, :]

    # apply smoother for parameter draw
    all_params_draw = (
        n_i, g_0_draw, d_draw, sigma_u_draw, 
        sigma_omega_draw, sigma_psi_draw, sigma_tau_draw, sigma_eps_star_draw, 
        rho_c_draw, lambda_c_draw, lambda_i_draw
    )
    res_draw = apply_kalman_filter(data, all_params_draw)
    simulation_smoother_states[i, :, :] = res_draw.states.smoothed.values.T


#%%
alpha = 0.05
state_quantiles = np.quantile(simulation_smoother_states, [alpha/2, 1-alpha/2], axis=0)
state_mean = np.mean(simulation_smoother_states, axis=0)

# plot true states versus Kalman smoother with true vs estimated parameters
for i in range(n_states):
    plt.figure(figsize=(10, 4))
    plt.plot(true_states[i, :])
    plt.plot(state_mean[i, :])
    plt.plot(state_quantiles[0, i, :])
    plt.plot(state_quantiles[1, i, :])
    plt.title(f'{i}: True versus estimated parameter smoother')
    plt.legend(['True', 'Mean', 'Lower', 'Upper'])
    plt.tight_layout()
    plt.show()
    

